export class CreateArticleDto {}
