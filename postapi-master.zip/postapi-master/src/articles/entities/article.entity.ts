export class Article {}
